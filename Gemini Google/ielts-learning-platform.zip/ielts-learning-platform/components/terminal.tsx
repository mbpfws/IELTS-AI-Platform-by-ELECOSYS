'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Play, Pause, Square, Share2, Loader2, Zap } from 'lucide-react'
import { ScrollArea } from "@/components/ui/scroll-area"
import { TaskManager, Task } from './task-manager'
import { useUser } from "@clerk/nextjs"
import { toast } from "@/components/ui/use-toast"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface Message {
  role: string;
  content: string;
}

export function Terminal() {
  const { user } = useUser();
  const [agentId, setAgentId] = useState<string | null>(null);
  const [agentName, setAgentName] = useState('')
  const [agentGoal, setAgentGoal] = useState('')
  const [userInput, setUserInput] = useState('')
  const [conversation, setConversation] = useState<Message[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])

  useEffect(() => {
    if (user) {
      fetchLastAgent();
    }
  }, [user]);

  const fetchLastAgent = async () => {
    try {
      const response = await fetch('/api/agent/last');
      if (response.ok) {
        const data = await response.json();
        if (data.agent) {
          setAgentId(data.agent.id);
          setAgentName(data.agent.name);
          setAgentGoal(data.agent.goal);
          setTasks(data.agent.tasks);
        }
      }
    } catch (error) {
      console.error('Error fetching last agent:', error);
      toast({
        title: "Error",
        description: "Failed to fetch the last agent. Please try again.",
        variant: "destructive",
      });
    }
  };

  const validateInputs = () => {
    if (!agentName.trim()) {
      toast({
        title: "Validation Error",
        description: "Agent name is required",
        variant: "destructive",
      });
      return false;
    }
    if (!agentGoal.trim()) {
      toast({
        title: "Validation Error",
        description: "Agent goal is required",
        variant: "destructive",
      });
      return false;
    }
    if (!userInput.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a question or prompt",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateInputs()) return;

    setIsLoading(true);
    setError(null);
    const newMessage: Message = { role: 'user', content: userInput };
    setConversation(prev => [...prev, newMessage]);
    setUserInput('');

    try {
      const response = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: userInput, 
          agentName, 
          agentGoal,
          conversation: [...conversation, newMessage],
          agentId
        }),
      });

      if (!response.ok) throw new Error('API call failed');

      const data = await response.json();
      setConversation(prev => [...prev, { role: 'assistant', content: data.reply }]);
      setAgentId(data.agentId);
      setTasks(data.tasks);
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred while processing your request. Please try again.');
      toast({
        title: "Error",
        description: "Failed to process your request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleTaskComplete = async (task: Task) => {
    try {
      const response = await fetch(`/api/agent/${agentId}/task/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'completed' }),
      });

      if (response.ok) {
        setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: 'completed' } : t));
        setConversation(prev => [
          ...prev, 
          { role: 'system', content: `Task "${task.description}" completed.` }
        ]);
        toast({
          title: "Task Completed",
          description: `Task "${task.description}" has been marked as completed.`,
        });
      }
    } catch (error) {
      console.error('Error updating task:', error);
      toast({
        title: "Error",
        description: "Failed to update the task. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4">
      <div className="flex-1 space-y-4">
        <Card className="bg-gray-900/50 border-gray-800 h-full flex flex-col">
          <div className="flex items-center p-2 border-b border-gray-800">
            <div className="flex space-x-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
            <div className="ml-4 text-sm text-gray-400 font-mono">
              IELTS Agent v1.0
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="ml-auto">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Share conversation (coming soon)</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <ScrollArea className="flex-1 p-4 font-mono text-sm text-gray-300">
            {conversation.length === 0 ? (
              <p>👋 Create an agent by adding a name / goal and click the deploy button!</p>
            ) : (
              conversation.map((message, index) => (
                <div key={index} className={`mb-2 ${
                  message.role === 'user' ? 'text-blue-400' : 
                  message.role === 'assistant' ? 'text-green-400' : 'text-yellow-400'
                }`}>
                  <strong>{message.role === 'user' ? 'You: ' : message.role === 'assistant' ? 'Agent: ' : 'System: '}</strong>
                  {message.content}
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex items-center text-yellow-400">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </div>
            )}
            {error && (
              <div className="text-red-400">
                Error: {error}
              </div>
            )}
          </ScrollArea>
        </Card>
      </div>

      <div className="mt-4 space-y-4">
        <div className="space-y-2">
          <Input
            placeholder="Agent Name"
            value={agentName}
            onChange={(e) => setAgentName(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
          <Input
            placeholder="Agent Goal"
            value={agentGoal}
            onChange={(e) => setAgentGoal(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
          <div className="flex space-x-2">
            <Input
              placeholder="Enter your question..."
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSubmit()}
              className="flex-grow bg-gray-800 border-gray-700 text-white"
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline"
                    size="icon"
                    onClick={handleSubmit}
                    disabled={isLoading}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Zap className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Send message</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        <div className="flex justify-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className={`text-gray-300 border-gray-700 ${isRunning ? 'bg-green-600' : ''}`}
                  onClick={() => {
                    setIsRunning(true)
                    handleSubmit()
                  }}
                  disabled={isLoading}
                >
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isRunning ? 'Agent is running' : 'Start agent'}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="text-gray-300 border-gray-700"
                  onClick={() => setIsRunning(false)}
                  disabled={isLoading}
                >
                  <Pause className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Pause agent</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="text-gray-300 border-gray-700"
                  onClick={() => {
                    setIsRunning(false)
                    setConversation([])
                    setAgentId(null)
                    setAgentName('')
                    setAgentGoal('')
                    setTasks([])
                  }}
                  disabled={isLoading}
                >
                  <Square className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Reset agent</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <TaskManager 
          tasks={tasks}
          onTaskComplete={handleTaskComplete}
        />
      </div>
    </div>
  )
}

