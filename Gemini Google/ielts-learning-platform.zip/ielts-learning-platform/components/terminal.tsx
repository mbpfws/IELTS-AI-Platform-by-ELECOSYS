'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Play, Pause, Square, Share2, Loader2 } from 'lucide-react'
import { ScrollArea } from "@/components/ui/scroll-area"
import { TaskManager, Task } from './task-manager'
import { useUser } from "@clerk/nextjs";

interface Message {
  role: string;
  content: string;
}

export function Terminal() {
  const { user } = useUser();
  const [agentId, setAgentId] = useState<string | null>(null);
  const [agentName, setAgentName] = useState('')
  const [agentGoal, setAgentGoal] = useState('')
  const [userInput, setUserInput] = useState('')
  const [conversation, setConversation] = useState<Message[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])

  useEffect(() => {
    if (user) {
      // Fetch the user's last used agent from the database
      fetchLastAgent();
    }
  }, [user]);

  const fetchLastAgent = async () => {
    try {
      const response = await fetch('/api/agent/last');
      if (response.ok) {
        const data = await response.json();
        if (data.agent) {
          setAgentId(data.agent.id);
          setAgentName(data.agent.name);
          setAgentGoal(data.agent.goal);
          setTasks(data.agent.tasks);
        }
      }
    } catch (error) {
      console.error('Error fetching last agent:', error);
    }
  };

  const handleSubmit = async () => {
    if (!agentName || !agentGoal || !userInput) return;

    setIsLoading(true);
    setError(null);
    const newMessage: Message = { role: 'user', content: userInput };
    setConversation(prev => [...prev, newMessage]);
    setUserInput('');

    try {
      const response = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: userInput, 
          agentName, 
          agentGoal,
          conversation: [...conversation, newMessage],
          agentId
        }),
      });

      if (!response.ok) throw new Error('Lỗi khi gọi API');

      const data = await response.json();
      setConversation(prev => [...prev, { role: 'assistant', content: data.reply }]);
      setAgentId(data.agentId);
      setTasks(data.tasks);
    } catch (error) {
      console.error('Lỗi:', error);
      setError('Đã xảy ra lỗi khi xử lý yêu cầu của bạn. Vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTaskComplete = async (task: Task) => {
    try {
      const response = await fetch(`/api/agent/${agentId}/task/${task.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'completed' }),
      });

      if (response.ok) {
        setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: 'completed' } : t));
        setConversation(prev => [
          ...prev, 
          { role: 'system', content: `Nhiệm vụ "${task.description}" đã hoàn thành.` }
        ]);
      }
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4">
      <div className="flex-1 space-y-4">
        <Card className="bg-gray-900/50 border-gray-800 h-full flex flex-col">
          <div className="flex items-center p-2 border-b border-gray-800">
            <div className="flex space-x-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
            <div className="ml-4 text-sm text-gray-400 font-mono">
              IELTS Agent v1.0
            </div>
            <Button variant="ghost" size="icon" className="ml-auto">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
          <ScrollArea className="flex-1 p-4 font-mono text-sm text-gray-300">
            {conversation.length === 0 ? (
              <p>👋 Tạo agent bằng cách thêm tên / mục tiêu và nhấn nút triển khai!</p>
            ) : (
              conversation.map((message, index) => (
                <div key={index} className={`mb-2 ${
                  message.role === 'user' ? 'text-blue-400' : 
                  message.role === 'assistant' ? 'text-green-400' : 'text-yellow-400'
                }`}>
                  <strong>{message.role === 'user' ? 'Bạn: ' : message.role === 'assistant' ? 'Agent: ' : 'Hệ thống: '}</strong>
                  {message.content}
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex items-center text-yellow-400">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Đang xử lý...
              </div>
            )}
            {error && (
              <div className="text-red-400">
                Lỗi: {error}
              </div>
            )}
          </ScrollArea>
        </Card>
      </div>

      <div className="mt-4 space-y-4">
        <div className="space-y-2">
          <Input
            placeholder="Tên Agent"
            value={agentName}
            onChange={(e) => setAgentName(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
          <Input
            placeholder="Mục tiêu của Agent"
            value={agentGoal}
            onChange={(e) => setAgentGoal(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
          <Input
            placeholder="Nhập câu hỏi của bạn..."
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSubmit()}
            className="bg-gray-800 border-gray-700 text-white"
          />
        </div>
        
        <div className="flex justify-center space-x-2">
          <Button 
            variant="outline" 
            size="icon" 
            className={`text-gray-300 border-gray-700 ${isRunning ? 'bg-green-600' : ''}`}
            onClick={() => {
              setIsRunning(true)
              handleSubmit()
            }}
            disabled={isLoading}
          >
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="text-gray-300 border-gray-700"
            onClick={() => setIsRunning(false)}
            disabled={isLoading}
          >
            <Pause className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="text-gray-300 border-gray-700"
            onClick={() => {
              setIsRunning(false)
              setConversation([])
              setAgentId(null)
              setAgentName('')
              setAgentGoal('')
              setTasks([])
            }}
            disabled={isLoading}
          >
            <Square className="h-4 w-4" />
          </Button>
        </div>

        <TaskManager 
          tasks={tasks}
          onTaskComplete={handleTaskComplete}
        />
      </div>
    </div>
  )
}

