'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Play, Pause, Square, Share2 } from 'lucide-react'

export function Terminal() {
  const [agentName, setAgentName] = useState('')
  const [agentGoal, setAgentGoal] = useState('')

  return (
    <div className="flex-1 flex flex-col p-4">
      <div className="flex-1 space-y-4">
        <Card className="bg-gray-900/50 border-gray-800">
          <div className="flex items-center p-2 border-b border-gray-800">
            <div className="flex space-x-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
            <div className="ml-4 text-sm text-gray-400 font-mono">
              IELTS Agent v1.0
            </div>
            <Button variant="ghost" size="icon" className="ml-auto">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
          <div className="p-4 font-mono text-sm text-gray-300 space-y-2">
            <p>👋 Tạo agent bằng cách thêm tên / mục tiêu và nhấn nút triển khai!</p>
            {/* Agent output will appear here */}
          </div>
        </Card>
      </div>

      <div className="mt-4 space-y-4">
        <div className="space-y-2">
          <Input
            placeholder="Tên Agent"
            value={agentName}
            onChange={(e) => setAgentName(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
          <Input
            placeholder="Mục tiêu của Agent"
            value={agentGoal}
            onChange={(e) => setAgentGoal(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
        </div>
        
        <div className="flex justify-center space-x-2">
          <Button variant="outline" size="icon" className="text-gray-300 border-gray-700">
            <Play className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="text-gray-300 border-gray-700">
            <Pause className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="text-gray-300 border-gray-700">
            <Square className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

