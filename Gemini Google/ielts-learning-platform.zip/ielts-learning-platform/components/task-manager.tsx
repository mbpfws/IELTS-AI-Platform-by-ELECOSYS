import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2 } from 'lucide-react'

export interface Task {
  id: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
}

interface TaskManagerProps {
  agentName: string;
  agentGoal: string;
  onTaskComplete: (task: Task) => void;
}

export function TaskManager({ agentName, agentGoal, onTaskComplete }: TaskManagerProps) {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTask, setNewTask] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (agentName && agentGoal) {
      setTasks([
        { id: '1', description: 'Khởi tạo Agent', status: 'completed' },
        { id: '2', description: `Phân tích mục tiêu: ${agentGoal}`, status: 'pending' },
      ])
    }
  }, [agentName, agentGoal])

  const addTask = async () => {
    if (!newTask) return
    setIsLoading(true)
    try {
      // In a real application, you would call an API to add the task
      const task: Task = { id: Date.now().toString(), description: newTask, status: 'pending' }
      setTasks([...tasks, task])
      setNewTask('')
    } catch (error) {
      console.error('Lỗi khi thêm nhiệm vụ:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const updateTaskStatus = async (taskId: string, newStatus: Task['status']) => {
    setIsLoading(true)
    try {
      // In a real application, you would call an API to update the task status
      const updatedTasks = tasks.map(task => 
        task.id === taskId ? { ...task, status: newStatus } : task
      )
      setTasks(updatedTasks)
      if (newStatus === 'completed') {
        const completedTask = updatedTasks.find(task => task.id === taskId)
        if (completedTask) onTaskComplete(completedTask)
      }
    } catch (error) {
      console.error('Lỗi khi cập nhật trạng thái nhiệm vụ:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Input
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Thêm nhiệm vụ mới"
          className="flex-grow"
        />
        <Button onClick={addTask} disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Thêm'}
        </Button>
      </div>
      <ul className="space-y-2">
        {tasks.map(task => (
          <li key={task.id} className="flex items-center justify-between bg-gray-800 p-2 rounded">
            <span className="text-sm">{task.description}</span>
            <select
              value={task.status}
              onChange={(e) => updateTaskStatus(task.id, e.target.value as Task['status'])}
              className="bg-gray-700 text-white text-sm rounded"
            >
              <option value="pending">Đang chờ</option>
              <option value="in_progress">Đang xử lý</option>
              <option value="completed">Hoàn thành</option>
              <option value="failed">Thất bại</option>
            </select>
          </li>
        ))}
      </ul>
    </div>
  )
}

