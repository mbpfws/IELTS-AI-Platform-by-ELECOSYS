import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2 } from 'lucide-react'

export interface Task {
  id: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
}

interface TaskManagerProps {
  tasks: Task[];
  onTaskComplete: (task: Task) => void;
}

export function TaskManager({ tasks, onTaskComplete }: TaskManagerProps) {
  const [newTask, setNewTask] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const addTask = async () => {
    if (!newTask) return
    setIsLoading(true)
    try {
      const response = await fetch('/api/agent/task', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: newTask }),
      });
      if (response.ok) {
        const task = await response.json();
        onTaskComplete({ ...task, status: 'pending' });
        setNewTask('');
      }
    } catch (error) {
      console.error('Lỗi khi thêm nhiệm vụ:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const updateTaskStatus = async (taskId: string, newStatus: Task['status']) => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/agent/task/${taskId}`, {
method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (response.ok) {
        const updatedTask = await response.json();
        onTaskComplete(updatedTask);
      }
    } catch (error) {
      console.error('Lỗi khi cập nhật trạng thái nhiệm vụ:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Input
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Thêm nhiệm vụ mới"
          className="flex-grow"
        />
        <Button onClick={addTask} disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Thêm'}
        </Button>
      </div>
      <ul className="space-y-2">
        {tasks.map(task => (
          <li key={task.id} className="flex items-center justify-between bg-gray-800 p-2 rounded">
            <span className="text-sm">{task.description}</span>
            <select
              value={task.status}
              onChange={(e) => updateTaskStatus(task.id, e.target.value as Task['status'])}
              className="bg-gray-700 text-white text-sm rounded"
            >
              <option value="pending">Đang chờ</option>
              <option value="in_progress">Đang xử lý</option>
              <option value="completed">Hoàn thành</option>
              <option value="failed">Thất bại</option>
            </select>
          </li>
        ))}
      </ul>
    </div>
  )
}

