import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { FileText, HelpCircle, Settings, User, Github, Twitter, Discord, Linkedin } from 'lucide-react'

export function Sidebar() {
  return (
    <div className="w-64 border-r border-gray-800 bg-gray-900/50 backdrop-blur-sm">
      <div className="flex h-full flex-col">
        <div className="p-4">
          <h2 className="text-lg font-semibold text-white">IELTS Agent</h2>
          <p className="text-sm text-gray-400">Tạo và lưu agent đầu tiên của bạn!</p>
        </div>
        
        <ScrollArea className="flex-1 px-4">
          <div className="space-y-4">
            <div className="text-xs font-semibold uppercase text-gray-400">Trang</div>
            <nav className="space-y-2">
              <Button variant="ghost" className="w-full justify-start gap-2 text-gray-300 hover:text-white">
                <FileText className="h-4 w-4" />
                Mẫu
              </Button>
              <Button variant="ghost" className="w-full justify-start gap-2 text-gray-300 hover:text-white">
                <HelpCircle className="h-4 w-4" />
                Trợ giúp
              </Button>
              <Button variant="ghost" className="w-full justify-start gap-2 text-gray-300 hover:text-white">
                <Settings className="h-4 w-4" />
                Cài đặt
              </Button>
              <Button variant="ghost" className="w-full justify-start gap-2 text-gray-300 hover:text-white">
                <User className="h-4 w-4" />
                Quản lý tài khoản
              </Button>
            </nav>
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-gray-800">
          <div className="flex justify-center space-x-4">
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <Github className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <Twitter className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <Discord className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <Linkedin className="h-5 w-5" />
            </Button>
          </div>
          <Button className="w-full mt-4 bg-orange-500 hover:bg-orange-600 text-white">
            Đăng ký
          </Button>
        </div>
      </div>
    </div>
  )
}

