import { ScrollArea } from "@/components/ui/scroll-area"

interface Task {
  id: number;
  description: string;
  status: 'pending' | 'completed';
}

interface TasksSidebarProps {
  tasks: Task[];
}

export function TasksSidebar({ tasks }: TasksSidebarProps) {
  return (
    <div className="w-64 border-l border-gray-800 bg-gray-900/50 backdrop-blur-sm">
      <div className="p-4">
        <h2 className="text-lg font-semibold text-white">Nhiệm vụ hiện tại</h2>
        <p className="text-sm text-gray-400">
          Danh sách các nhiệm vụ của agent.
        </p>
      </div>
      <ScrollArea className="h-[calc(100vh-120px)]">
        <div className="p-4">
          {tasks.map((task) => (
            <div key={task.id} className="mb-2 p-2 bg-gray-800 rounded">
              <p className="text-sm text-gray-300">{task.description}</p>
              <span className={`text-xs ${task.status === 'completed' ? 'text-green-400' : 'text-yellow-400'}`}>
                {task.status === 'completed' ? 'Hoàn thành' : 'Đang xử lý'}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

