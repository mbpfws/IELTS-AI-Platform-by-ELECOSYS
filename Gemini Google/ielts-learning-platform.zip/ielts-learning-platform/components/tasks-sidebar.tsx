import { ScrollArea } from "@/components/ui/scroll-area"

export function TasksSidebar() {
  return (
    <div className="w-64 border-l border-gray-800 bg-gray-900/50 backdrop-blur-sm">
      <div className="p-4">
        <h2 className="text-lg font-semibold text-white">Nhiệm vụ hiện tại</h2>
        <p className="text-sm text-gray-400">
          Cửa sổ này sẽ hiển thị các nhiệm vụ của agent khi chúng được tạo.
        </p>
      </div>
      <ScrollArea className="h-[calc(100vh-120px)]">
        <div className="p-4">
          {/* Tasks will appear here */}
        </div>
      </ScrollArea>
    </div>
  )
}

