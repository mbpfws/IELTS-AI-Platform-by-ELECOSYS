'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/sidebar'
import { Terminal } from '@/components/terminal'
import { TasksSidebar } from '@/components/tasks-sidebar'

export default function Home() {
  const [tasks, setTasks] = useState([
    { id: 1, description: 'Khởi tạo Agent', status: 'completed' as const },
    { id: 2, description: 'Phân tích yêu cầu người dùng', status: 'pending' as const },
    { id: 3, description: 'Tạo phản hồi', status: 'pending' as const },
  ]);

  return (
    <>
      <Sidebar />
      <Terminal />
      <TasksSidebar tasks={tasks} />
    </>
  )
}

