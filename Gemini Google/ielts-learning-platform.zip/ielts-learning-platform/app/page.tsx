import { Sidebar } from '@/components/sidebar'
import { Terminal } from '@/components/terminal'
import { TasksSidebar } from '@/components/tasks-sidebar'

export default function Home() {
  return (
    <>
      <Sidebar />
      <Terminal />
      <TasksSidebar />
    </>
  )
}

