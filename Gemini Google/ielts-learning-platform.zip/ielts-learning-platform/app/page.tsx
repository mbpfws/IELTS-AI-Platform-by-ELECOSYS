import Link from 'next/link'
import { UserButton } from "@clerk/nextjs";

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">IELTS Learning Hub</h1>
        <UserButton afterSignOutUrl="/"/>
      </header>
      <nav className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {['Reading', 'Writing', 'Listening', 'Speaking', 'Grammar', 'Vocabulary'].map((skill) => (
          <Link 
            key={skill} 
            href={`/${skill.toLowerCase()}`}
            className="p-6 text-center bg-white dark:bg-gray-800 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out"
          >
            {skill}
          </Link>
        ))}
      </nav>
    </div>
  )
}

