import { auth } from '@clerk/nextjs'
import { redirect } from 'next/navigation'
import { Sidebar } from '@/components/sidebar'
import { Terminal } from '@/components/terminal'
import { TasksSidebar } from '@/components/tasks-sidebar'

export default async function Home() {
  const { userId } = await auth()
  
  if (!userId) {
    redirect('/sign-in')
  }

  return (
    <>
      <Sidebar />
      <Terminal />
      <TasksSidebar tasks={[]} />
    </>
  )
}

