import { auth } from '@clerk/nextjs'
import { redirect } from 'next/navigation'
import { Sidebar } from '@/components/sidebar'
import { Terminal } from '@/components/terminal'
import { TasksSidebar } from '@/components/tasks-sidebar'
import ErrorBoundary from '@/components/error-boundary'

export default async function Home() {
  const { userId } = await auth()
  
  if (!userId) {
    redirect('/sign-in')
  }

  return (
    <ErrorBoundary>
      <Sidebar />
      <Terminal />
      <TasksSidebar tasks={[]} />
    </ErrorBoundary>
  )
}

