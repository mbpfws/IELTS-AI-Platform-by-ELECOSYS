import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { description } = await req.json();

    const lastAgent = await prisma.agent.findFirst({
      where: { userId },
      orderBy: { updatedAt: 'desc' },
    });

    if (!lastAgent) {
      return NextResponse.json({ error: 'No agent found' }, { status: 404 });
    }

    const task = await prisma.task.create({
      data: {
        description,
        status: 'pending',
        agentId: lastAgent.id,
      },
    });

    return NextResponse.json(task);
  } catch (error) {
    console.error('Error creating task:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

