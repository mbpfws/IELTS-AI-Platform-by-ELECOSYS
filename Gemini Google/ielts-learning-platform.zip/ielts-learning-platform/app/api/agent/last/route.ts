import { NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const lastAgent = await prisma.agent.findFirst({
      where: { userId },
      orderBy: { updatedAt: 'desc' },
      include: { tasks: true },
    });

    return NextResponse.json({ agent: lastAgent });
  } catch (error) {
    console.error('Error fetching last agent:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

