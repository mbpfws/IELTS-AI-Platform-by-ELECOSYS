import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextRequest, NextResponse } from "next/server";
import { auth } from '@clerk/nextjs';
import { prisma } from '@/lib/prisma';

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_GEMINI_API_KEY!);

export async function POST(req: NextRequest) {
  try {
    const { userId } = auth();
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { prompt, agentName, agentGoal, conversation, agentId } = await req.json();

    let agent;
    if (agentId) {
      agent = await prisma.agent.findUnique({
        where: { id: agentId, userId },
        include: { tasks: true },
      });
      if (!agent) {
        return NextResponse.json({ error: 'Agent not found' }, { status: 404 });
      }
    } else {
      agent = await prisma.agent.create({
        data: {
          name: agentName,
          goal: agentGoal,
          userId,
          tasks: {
            create: [
              { description: 'Khởi tạo Agent', status: 'completed' },
              { description: `Phân tích mục tiêu: ${agentGoal}`, status: 'pending' },
            ],
          },
        },
        include: { tasks: true },
      });
    }

    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const chat = model.startChat({
      history: [
        {
          role: "user",
          parts: `Bạn là một trợ lý AI có tên ${agent.name}. Mục tiêu của bạn là ${agent.goal}. Hãy trả lời câu hỏi sau đây một cách chuyên nghiệp và hữu ích, đồng thời luôn ghi nhớ mục tiêu của bạn.`,
        },
        {
          role: "model",
          parts: "Xin chào! Tôi là trợ lý AI được tạo ra để giúp bạn. Tôi sẽ cố gắng hết sức để đạt được mục tiêu đã đề ra. Bạn có câu hỏi gì không?",
        },
        ...conversation.map((msg: { role: string; content: string }) => ({
          role: msg.role === 'user' ? 'user' : 'model',
          parts: msg.content,
        })),
      ],
    });

    const result = await chat.sendMessage(prompt);
    const response = await result.response;
    const text = response.text();

    // Update the agent's tasks based on the AI's response
    const updatedTasks = agent.tasks.map(task => {
      if (task.status === 'pending' && text.toLowerCase().includes(task.description.toLowerCase())) {
        return { ...task, status: 'completed' };
      }
      return task;
    });

    await prisma.agent.update({
      where: { id: agent.id },
      data: {
        tasks: {
          updateMany: updatedTasks.map(task => ({
            where: { id: task.id },
            data: { status: task.status },
          })),
        },
      },
    });

    return NextResponse.json({ reply: text, agentId: agent.id, tasks: updatedTasks });
  } catch (error: any) {
    console.error("Error in AI agent:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

