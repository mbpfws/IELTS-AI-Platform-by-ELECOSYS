import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextRequest, NextResponse } from "next/server";

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_GEMINI_API_KEY!);

export async function POST(req: NextRequest) {
  try {
    const { prompt, agentName, agentGoal } = await req.json();

    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const chat = model.startChat({
      history: [
        {
          role: "user",
          parts: `Bạn là một trợ lý AI có tên ${agentName}. Mục tiêu của bạn là ${agentGoal}. Hãy trả lời câu hỏi sau đây một cách chuyên nghiệp và hữu ích.`,
        },
        {
          role: "model",
          parts: "Xin chào! Tôi là trợ lý AI được tạo ra để giúp bạn. Tôi sẽ cố gắng hết sức để đạt được mục tiêu đã đề ra. Bạn có câu hỏi gì không?",
        },
      ],
    });

    const result = await chat.sendMessage(prompt);
    const response = await result.response;
    const text = response.text();

    return NextResponse.json({ reply: text });
  } catch (error: any) {
    console.error("Error in AI agent:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

