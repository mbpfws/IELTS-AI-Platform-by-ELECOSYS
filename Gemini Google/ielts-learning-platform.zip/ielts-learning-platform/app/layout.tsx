import { ClerkProvider } from '@clerk/nextjs'
import { Inter, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin', 'vietnamese'] })
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="vi">
        <body className={inter.className}>
          <div className="flex h-screen bg-gradient-to-b from-gray-900 to-gray-800">
            {children}
          </div>
        </body>
      </html>
    </ClerkProvider>
  )
}

