import { ClerkProvider } from '@clerk/nextjs'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin', 'vietnamese'] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="vi">
        <body className={inter.className}>
          <div className="flex h-screen bg-gradient-to-b from-gray-900 to-gray-800">
            {children}
          </div>
        </body>
      </html>
    </ClerkProvider>
  )
}

